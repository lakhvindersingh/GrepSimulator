It is the way to find the any keyword from files.

Firstly,  upload 'grep'  folder in root directory(Please find the attachment for grep).
If your project name is 'school'. Then find any keyword using following url.

http://localhost/school/grep?s=any keyword that you want to find from files

For example if you want to find "wrapper" class or keyword.

Then hit this url on browser .... http://localhost/school/grep?s=wrapper

After that browser will show all files location which file have 'wrapper' word.